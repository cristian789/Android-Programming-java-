package ed.niu.cristianaguirre.assignment2;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity

{
    //instance variable
    private EditText num1ET, num2ET;
    private TextView answerTV;

    private Button addBTN, clearBTN,
            minBTN, multiplyBTN, divBTN;          //adding minus, multiply and division to the calculator function

    private Integer num1,num2, result;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect the instance variables with the objects on the screen
        num1ET = findViewById(R.id.num1EditText);
        num2ET = findViewById(R.id.num2EditText);

        answerTV = findViewById(R.id.answearTextView);

        addBTN = findViewById(R.id.addButton);

        minBTN = findViewById(R.id.minusButton); //adding minus find view byID
        multiplyBTN = findViewById(R.id.multiplyButton);
        divBTN = findViewById(R.id.divideButton);

        clearBTN = findViewById(R.id.clearButton);


        //handle the addition button being cleared
        addBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                //check for empty fields
                if( num1ET.getText().toString().matches("") ||
                        num2ET.getText().toString().matches(""))
                {
                    //display an error message and exit the onCLock method
                    Toast.makeText(v.getContext(), "cannot have an emptu field", Toast.LENGTH_LONG).show();
                    return;
                }


                //get the numbers that the user entered
                num1 = Integer.parseInt(num1ET.getText().toString() );
                num2 = Integer.parseInt(num2ET.getText().toString() );

                //calculate the sum
                result = num1 + num2;

                //put the sum on the screen
                answerTV.setText(result.toString() );
            }//end click
        });


        //handle the subtraction button being cleared
        minBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                //check for empty fields
                if( num1ET.getText().toString().matches("") ||
                        num2ET.getText().toString().matches(""))
                {
                    //display an error message and exit the onCLock method
                    Toast.makeText(v.getContext(), "cannot have an emptu field", Toast.LENGTH_LONG).show();
                    return;
                }


                //get the numbers that the user entered
                num1 = Integer.parseInt(num1ET.getText().toString() );
                num2 = Integer.parseInt(num2ET.getText().toString() );

                //calculate the subtraction
                result = num1 - num2;

                //put the sum on the screen
                answerTV.setText(result.toString() );
            }//end click
        });


        //handle the multiplication button being cleared
        multiplyBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                //check for empty fields
                if( num1ET.getText().toString().matches("") ||
                        num2ET.getText().toString().matches(""))
                {
                    //display an error message and exit the onCLock method
                    Toast.makeText(v.getContext(), "cannot have an emptu field", Toast.LENGTH_LONG).show();
                    return;
                }


                //get the numbers that the user entered
                num1 = Integer.parseInt(num1ET.getText().toString() );
                num2 = Integer.parseInt(num2ET.getText().toString() );

                // calculate the multiplication
                result = num1 * num2;

                //put the multiplication on the screen
                answerTV.setText(result.toString());
            }//end click
        });


        //handle division button
        divBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                //check for empty fields
                if( num1ET.getText().toString().matches("") ||
                    num2ET.getText().toString().matches("")) {

                    //display error if empty on one of the text fields on calculator
                    Toast.makeText(v.getContext(), "cannot have an empty field", Toast.LENGTH_LONG).show();
                    return;
                }

                //get the numbers that the user entered
                num1 = Integer.valueOf(num1ET.getText().toString());
                num2 = Integer.valueOf(num2ET.getText().toString());

                //calculate the division
                result = num1 / num2;

                //put the division on the screen
                answerTV.setText(result.toString());

            }//end click
        });


        clearBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                //setting the text fields to empty text fields once clear btn is pressed
                num1ET.setText("");
                num2ET.setText("");
                answerTV.setText("");
            }//end click
        });

    }
}
