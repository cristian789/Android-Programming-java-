package ed.niu.cristianaguirre.caloriecalculator;

public class Burger
{
    //constants
    static final int BEEF = 90,
                     TURKEY = 170,
                     VEGGIE = 150,
                     CHEDDAR = 113,
                     MOZZ = 78,
                     BACON = 86;

    //data members
    private int pattyCalories, cheeseCalories, baconCalories, sauceCalories;


    //constructor


    public Burger()
    {
        pattyCalories = BEEF;
        cheeseCalories = 0;
        baconCalories = 0;
        sauceCalories = 0;
    } //end of constructor


    public void setPattyCalories(int newCalories) {
        pattyCalories = newCalories;
    }

    public void setCheeseCalories(int newCalories) {
        cheeseCalories = newCalories;
    }



    public void setBaconCalories(boolean hasBacon) {

        if (hasBacon)
        baconCalories = BACON;

        else
            baconCalories = 0;

    }

    public void setSauceCalories(int newCalories) {
        sauceCalories = newCalories;
    }

    //method to calculate total member of calories
    public int getTotalCalories()
    {
        return pattyCalories + cheeseCalories + baconCalories + sauceCalories;
    } // end of get total Calories

}//end burger class
