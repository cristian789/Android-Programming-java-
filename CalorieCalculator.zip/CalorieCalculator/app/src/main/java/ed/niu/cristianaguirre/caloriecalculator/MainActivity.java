package ed.niu.cristianaguirre.caloriecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private RadioGroup pattyRG, cheeseRG;
    private CheckBox baconCB;
    private SeekBar sauceSB;
    private TextView caloriesTV;

    private Burger burger;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //default


        //connect the variables to the objects on the screen
        pattyRG = findViewById(R.id.pattyRadioGroup);
        cheeseRG = findViewById(R.id.cheeseRadioGroup);

        baconCB = findViewById(R.id.baconCheckBox);

        sauceSB = findViewById(R.id.seekBar);

        caloriesTV = findViewById(R.id.caloriesTextView);

        //create the burger
        burger = new Burger();

        displayCalories();

        //set up the name listener for the patty selection
        pattyRG.setOnCheckedChangeListener(pattyListener);

        //set up the anon. listener for the cheese selection
        cheeseRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch (checkedId)
                {
                    case R.id.nochesseRadioButton:    burger.setCheeseCalories(0);
                                                        break;    //you need break to reset once you choose another one

                    case R.id.cheddarRadioButton:     burger.setCheeseCalories(Burger.CHEDDAR);
                                                        break;

                    case R.id.mozzarellaRadioButton:   burger.setCheeseCalories(Burger.MOZZ);
                                                        break;
                }//end of switch

                displayCalories();
            }
        });

        //set up name listerner for the bacon checkBoz
        baconCB.setOnClickListener(baconListener);

        //set up the name listener for the sauce seekBar
        sauceSB.setOnSeekBarChangeListener( sauceListener );

    }//end on create


    private SeekBar.OnSeekBarChangeListener sauceListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
        {
            burger.setSauceCalories( seekBar.getProgress());   //how much progrees has been move with it
            displayCalories();
        }//end progress changed

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }  //end of on click
    };  //end of onSeekBarChange


    private View.OnClickListener baconListener = new View.OnClickListener()
    {
        @Override
        public void onClick (View view)
        {
            if ( ( (CheckBox) view).isChecked() )
            {
                burger.setBaconCalories (true);
            }

            else
            {
                burger.setBaconCalories(false);
            }

            displayCalories();

        } //end on click
    }; //end onClickListener



    private RadioGroup.OnCheckedChangeListener pattyListener = new RadioGroup.OnCheckedChangeListener()
    {
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int checkedID)
        {
            switch (checkedID) {
                case R.id.beefRadioButton:        burger.setPattyCalories(Burger.BEEF);
                                                  break;

                case R.id.turkeyRadioButto:       burger.setPattyCalories(Burger.TURKEY);
                                                  break;

                case R.id.veggieRadioButton:      burger.setPattyCalories(Burger.VEGGIE);
                                                  break;

            } //end of switch case for patty
            displayCalories();

        } // end of on Checked change

    }; //end of patty listener




    private void displayCalories()
    {
        //build the strings to be displayed
        String caloriesText = "Calories: " + burger.getTotalCalories();


        //display the string in the text view
        caloriesTV.setText(caloriesText);

    } //end displayCalories
}//end MainActivity
