package ed.niu.cristianaguirre.shippingcalculator;

public class ShippingItem
    {
        //constants
        static final  Double Base_Amount = 3.00,
                             Added_Amount = 0.50,
                             Extra_Ounces = 4.0;
        static final  int Base_Weight = 16;

        //variables
        private Integer weight;
        private Double baseCost, addedCost, totalCost;


        public ShippingItem()
        {
            weight = 0;
            baseCost = Base_Amount;
            addedCost = 0.0;
            totalCost = 0.0;
        }

        public void setWeight(Integer newWeight)
        {
            this.weight = newWeight;
            computeCost();

        }//end of setWeight method


        public void computeCost()
        {
            baseCost = Base_Amount;
            if (weight <= 0)
                baseCost = 0.0;

            //calculate the additional cost

            addedCost = 0.0;
            if (weight > Base_Weight)
                addedCost = Math.ceil( (weight - Base_Weight)/ Extra_Ounces ) * Added_Amount;


            //calculate the total cost
            totalCost = baseCost + addedCost;



        }//end of computeCost

        public Double getBaseCost()
        {
            return baseCost;
        }

        public Double getAddedCost()
        {
            return addedCost;
        }

        public Double getTotalCost()
        {
            return totalCost;
        }
    } //end of shippingItem Class
