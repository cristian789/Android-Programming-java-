package edu.niu.cristianaguirre.top5americancars;

/*************************************************************
 *
 * Programmer -  Cristian Aguirre Alvizo
 *
 * Purpose: To learn about Spinners and transferring information from one
 * view to the other.
 *
 *************************************************************/


public class SpinnerInfo {

    static public String valueArray[] = {"Mustang GT500", "Camaro ZL1", "Charger SRT Hellcat", "Challenger STR Demon", "Viper ACR" };

   // static public int idArray[] = {R.drawable.ic_launcher_background};
}
