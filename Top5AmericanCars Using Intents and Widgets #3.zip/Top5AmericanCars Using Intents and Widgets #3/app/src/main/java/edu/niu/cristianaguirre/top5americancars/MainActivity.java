package edu.niu.cristianaguirre.top5americancars;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

/*************************************************************
 *
 * Programmer -  Cristian Aguirre Alvizo
 *
 * Purpose: To learn about Spinners and transferring information from one
 * view to the other.
 *
 *************************************************************/


public class MainActivity extends Activity {


    //format to pass strings from one view to another thru intents
    public static final String EXTRA_TEXT = "edu.niu.cristianaguirre.top5americancars_EXTRA_TEXT";          //good practice for inside text

    public static final String EXTRA_TEXT_TITLE = "edu.niu.cristianaguirre.top5americancars_EXTRA_TEXT_TITLE";


    private Spinner classSpin;   //creating a spinner

    private ImageView image;     //image

    private String titleCar;     //to pass the title of the car


    private String textInfo;   //car specs strings



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //populate the spinner using information from a class
        classSpin = findViewById(R.id.carSpinner);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                                                            R.layout.spinner_view,
                                                            SpinnerInfo.valueArray);

        image = (ImageView) findViewById(R.id.imageView);



        classSpin.setAdapter(adapter);                                                              //setting the adapter for the spinner
        classSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {   //setting up the class for onItemSelected

                    String selection;

                    selection = parent.getItemAtPosition(position).toString();

                   Toast.makeText(getApplicationContext(),selection, Toast.LENGTH_SHORT).show();




                   if (position == 0)                                           //each car is being passed by an array position so that defines the car being pressed
                   {
                       image.setImageResource(R.drawable.fordmustanggt500);     //passing in the image of selected car from drawable

                       titleCar = selection;                                    //we already have the title so why not just pass it

                       textInfo = "Overview \n\n    The Shelby GT500 is the ultimate Mustang" +
                               " with 700-plus horsepower and more go-fast goodies" +
                               " than a speed shop. When it goes on sale this summer" +
                               ", it will face off against high-powered pony cars such " +
                               "as the 650-hp Chevy Camaro ZL1 and the 717-hp Dodge" +
                               " Challenger SRT Hellcat. The legendary GT500 nameplate" +
                               " slots above the track-ready Shelby GT350, and it wears" +
                               " a distinct front end with different optional wings that" +
                               " makes them easy to separate.\n\n" +
                               "Engine, Ride, and Handling \n\n" +
                               "    Featuring a supercharged 5.2-liter V-8 mated to a " +
                               "seven-speed dual-clutch automatic, Ford says the GT500 " +
                               "will be able to hit 60 mph in less than three seconds " +
                               "and turn the quarter-mile in less than eleven seconds. " +
                               "A carbon-fiber driveshaft routes all that thrust to the " +
                               "rear wheels; the dual-clutch transmission is capable of " +
                               "changing gears in less than 100 milliseconds. When it " +
                               "comes to ride, handling, and braking, the GT500 boasts " +
                               "adaptive dampers along with sticky Michelin Pilot Sport " +
                               "4S tires with unique compound and tread. Stopping power " +
                               "is provided by Brembo, with 16.5-inch rotors and six-piston " +
                               "calipers. There are two performance-oriented options: the" +
                               " Handling package includes adjustable strut top mounts " +
                               "and a spoiler with a Gurney flap; the Carbon Fiber Track" +
                               " package features exposed 20-inch carbon-fiber wheels shod " +
                               "with Michelin Pilot Sport Cup 2 tires, an adjustable " +
                               "carbon-fiber track wing, and splitter wickers with an " +
                               "integrated dive plane. The rear seat is deleted to save weight.";
                   }

                   else if (position == 1)
                   {
                       image.setImageResource(R.drawable.camaroszl1);

                       titleCar = selection;

                       textInfo = "Overview \n\n    Find the 455-hp 6.2-liter V-8 in the " +
                               "Camaro SS too boring or underpowered? Chevrolet won't tell " +
                               "you to get your head checked. Instead, it slaps a supercharger " +
                               "on that V-8, boosts the output to 650 horsepower, and installs " +
                               "it along with a host of suspension and styling upgrades to create " +
                               "the ZL1. Available as either a coupe or a convertible—with your " +
                               "choice of a six-speed manual transmission or a 10-speed automatic " +
                               "with paddle shifters—the ZL1 stands atop the Camaro pile to see eye " +
                               "to eye with the Ford Mustang Shelby GT350 and the Dodge Challenger " +
                               "SRT Hellcat. In fact, if you consider the ZL1's breathtaking " +
                               "performance at our 2017 Lightning Lap competition, it looks down " +
                               "on those competitors.\n\n" +
                               "Engine, Ride, and Handling \n\n" +
                               "    The Camaro's supercharged 6.2-liter V-8, borrowed from the pricier " +
                               "Chevrolet Corvette Z06, is a well-behaved and tractable beast that " +
                               "makes power all over the rev range and leaves black streaks all over " +
                               "the road. And as you'd expect, when stirred up, it leaves the sound " +
                               "of thunder echoing in its wake. Whether paired with the standard " +
                               "six-speed manual transmission or the available 10-speed automatic, " +
                               "the blown small-block V-8 lays down stupidly incredible performance " +
                               "figures. The fast-shifting automatic, as is common these days, " +
                               "results in quicker acceleration times than the stick, but either " +
                               "way the Camaro smokes its competition at the drag strip.";
                   }

                   else if (position == 2)
                   {
                       image.setImageResource(R.drawable.chargerhellcat1);

                       titleCar = selection;

                       textInfo = "Overview \n\n    The Dodge Charger SRT Hellcat is a 707 hp," +
                               " 645 lb-ft 6.2-liter V8 supercharged four-door performance " +
                               "sedan. An 8-speed automatic transmission and rear-wheel drive " +
                               "layout are standard as is class-beating performance. A hard " +
                               "ride and subpar interior quality are weak points but a spacious " +
                               "interior and comprehensive list of standard equipment will " +
                               "appeal to many shoppers. A full range of driver safety systems " +
                               "such as blind spot and cross path detection are also included, " +
                               "and did we mention that it has 707hp?\n\n" +
                               "Dodge Charger SRT Hellcat Review \n\n   " +
                               "The Charger SRT Hellcat sits atop the full-size sedan hierarchy" +
                               " in Dodge’s range courtesy of a massive supercharged V8. In fact," +
                               " its top speed and power output outclass just about any sedan" +
                               " around and if sportscar performance in a spacious bodyshell is" +
                               " high on your list of priorities then this may well be the car for you." +
                               "The Hellcat receives minor changes for this model year, with a new " +
                               "choice of alloy wheels and updated infotainment system being the" +
                               " most noteworthy.";
                   }

                   else if (position == 3)
                   {
                       image.setImageResource(R.drawable.challengerdemon);

                       titleCar = selection;

                       textInfo = "Overview \n\n    The Challenger SRT Demon is even mightier than " +
                               "the Hellcat version, boasting up to 840 horsepower and exclusive " +
                               "drag-racing equipment. Did we mention that it can do a wheelie, " +
                               "too? While the limited-edition Demon went out of production after " +
                               "the 2018 model year, it remains one of the coolest and craziest cars " +
                               "to ever wear a Dodge badge. Many of its engine and transmission " +
                               "goodies are now available on the Challenger SRT Hellcat Redeye. " +
                               "Still, even the most powerful pony-car competitors, such as the " +
                               "650-hp Chevy Camaro ZL1 and the all-new 700-plus-horsepower " +
                               "Ford Mustang Shelby GT500, will be hard-pressed to match the " +
                               "straight-line acceleration of the Demon.\n\n" +
                               "Engine, Ride, and Handling \n\n" +
                               "    The heart of this demonic Challenger is its 808-hp supercharged " +
                               "6.2-liter Hemi V-8. Wait, didn't we already say it makes 840 " +
                               "horsepower? That is correct, but only when the gas tank is filled " +
                               "with 100-plus-octane race fuel and the $1 Demon Crate package is " +
                               "added, which includes a special engine controller that helps unlock " +
                               "the engine's full potential. Add—or should we say subtract—numerous " +
                               "interior pieces to make it lighter, along with the many other " +
                               "weight-saving methods, and Dodge claims the Demon can cover the " +
                               "quarter-mile in 9.65 seconds at 140 mph. What does that mean? It's " +
                               "(expletive) fast, that's what.";
                   }

                   else
                   {
                       image.setImageResource(R.drawable.viperacr1);

                       titleCar = selection;

                       textInfo = "Overview \n\n    The Dodge Viper ACR is the fastest Viper around " +
                               "a racetrack—at least that’s what Dodge claims—but a 177-mph top speed " +
                               "makes it the slowest Viper. With the exception of a finned differential " +
                               "for cooling, the ACR’s drivetrain is identical to that found in the rest " +
                               "of the Viper lineup. That means an 8.4-liter V-10 that throbs out 645 " +
                               "horsepower and 600 lb-ft of torque and looks to be about the size of a " +
                               "steamer trunk. What makes the Viper ACR faster around a racetrack is also " +
                               "what reduces its straight-line speed—downforce. Downforce uses air for " +
                               "the very noble purpose of pushing a car down into the earth. The harder " +
                               "the air pushes the car into the tarmac, the faster the car can corner. " +
                               "But downforce also creates aerodynamic drag, which slows down a car at " +
                               "the top end. Imagine an upside-down set of airplane wings strapped to " +
                               "the roof of a Viper and you have a decent idea of how it works.\n\n" +
                               "Wings on Wings off\n\n  By default, a huge adjustable wing is bolted to the Viper ACR’s " +
                               "trunklid, a massive front splitter gives the car an underbite, " +
                               "the front bumper is flanked by a dive-plane moustache, fender " +
                               "vents perched above the front tires reduce lift, and a rear diffuser " +
                               "cuts the air like a mandolin slicer. Opt for the ACR Extreme package, " +
                               "however, and the wing, splitter, and diffuser all grow, making them " +
                               "even more effective and pushing the ACR harder into the asphalt—to the " +
                               "tune of 2000 pounds of downforce at its 177-mph top speed. The penalty " +
                               "comes in terms of the stated drag coefficient, which is 0.54 for the " +
                               "ACR Extreme versus 0.37 for the regular Viper SRT and 0.43 for the Viper TA.";
                   }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }//end onCreate

    //this is the class for on click to go to the next view
    public void goToCarInfo (View view)
    {
        Intent intentInfo = new Intent( MainActivity.this, spinerCarSpecs.class);

        intentInfo.putExtra(EXTRA_TEXT_TITLE, titleCar);  //this passes the title to the next view

        intentInfo.putExtra(EXTRA_TEXT, textInfo);        //this passes car specs info thru the intent put extra function

        startActivity(intentInfo);



    }



}//end mainActivity
