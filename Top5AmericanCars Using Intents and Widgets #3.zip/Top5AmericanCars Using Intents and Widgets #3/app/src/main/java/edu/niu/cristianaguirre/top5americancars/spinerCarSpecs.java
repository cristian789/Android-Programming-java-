package edu.niu.cristianaguirre.top5americancars;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

/*************************************************************
 *
 * Programmer -  Cristian Aguirre Alvizo
 *
 * Purpose: To learn about Spinners and transferring information from one
 * view to the other.
 *
 *************************************************************/



public class spinerCarSpecs extends Activity {


  //  private ScrollView scroll;

    private TextView textViews , titleTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spiner_car_specs);



        Intent intent = getIntent();      //intent to get intent

        String title = intent.getStringExtra(MainActivity.EXTRA_TEXT_TITLE);    //getting the title

        String text = intent.getStringExtra(MainActivity.EXTRA_TEXT);           //getting the text specs

        textViews = (TextView) findViewById(R.id.textViewCars);                 //pointing the intent information to text view to the one in xml

        textViews.setText(text);



        //getting the title

        titleTextView = (TextView) findViewById(R.id.titleTextView);

        titleTextView.setText(title);



    }//end onCreate


    public void goBack (View view)
    {
        finish();
    }//end goBack




}//end mainActivity
