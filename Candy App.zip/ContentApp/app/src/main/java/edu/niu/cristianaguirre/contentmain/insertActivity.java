package edu.niu.cristianaguirre.contentmain;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class insertActivity extends AppCompatActivity {

    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        databaseManager = new DatabaseManager(this);
    }//end on create

    public void insertCandy (View view)
    {
        //get the info from the editText fields
        EditText candyNameET = findViewById(R.id.editText),
                priceET = findViewById(R.id.editText2);

        String nameStr = candyNameET.getText().toString(),
                priceStr = priceET.getText().toString();

        try
            {
              double price = Double.parseDouble(priceStr);

              //creaete the candy object
              Candy candy = new Candy(0, nameStr, price);

             //insert the cnady object intot the database
             databaseManager.insert(candy);

             Toast.makeText(this, "Candy " + nameStr + "added to DB", Toast.LENGTH_SHORT).show();
          }

        catch (NumberFormatException nfe)
            {
                Toast.makeText(this, "Price error", Toast.LENGTH_SHORT).show();

            }

        ArrayList<Candy> candies = databaseManager.selectAll();
        for (Candy candy : candies )
        {
            Toast.makeText(this, "The candy is " + candy.candyToString(), Toast.LENGTH_SHORT).show();
        }

        //clear the edit text fields
        candyNameET.setText("");
        priceET.setText("");
    }//end insertCandy

    //Back button
    public void goBack (View view)
    {
        finish();
    }//end goBack



}//end insertActivity
