package edu.niu.cristianaguirre.contentmain;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Scroller;
import android.widget.Toast;

import java.util.ArrayList;

public class DeleteActivity extends AppCompatActivity {

    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        databaseManager = new DatabaseManager(this);
        updataView();
    }//end onCreate

    public void updataView()
    {
        ArrayList<Candy> candies = databaseManager.selectAll();

        //create the layout
        RelativeLayout layout = new RelativeLayout(this);

        ScrollView scrollView = new ScrollView(this);

        RadioGroup radioGroup = new RadioGroup(this);

        //loop to process each candy in the array list
        for (Candy candy : candies)
        {
            //create a radiobutton to be place into the radiogrop
            RadioButton radioButton = new RadioButton(this);

            //put the info into the radio button
            radioButton.setId(candy.getId());
            radioButton.setText(candy.candyToString());

            //add the radiobutton to the radioGroup
            radioGroup.addView(radioButton);

        }//end for loop
    //set up the handler for the raidobuttons in the radiogroup
    RadioButtonHandler handler = new RadioButtonHandler();
    radioGroup.setOnCheckedChangeListener(handler);

    //create a back button
        Button backBTN = new Button(this);
        backBTN.setText("Back");
        backBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    //add radiogroup to the scrollview
    scrollView.addView(radioGroup);

    //add the scrollview to the relative view
    layout.addView(scrollView);

    //set up some parameters to make the back button display at the buttom of the screen
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                                                                            ViewGroup.LayoutParams.WRAP_CONTENT);

        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        params.setMargins(0, 0, 0, 50);

    //add the back button to the relative layout using the parameters
        layout.addView(backBTN, params);

    //display the layout
    setContentView(layout);

    }//end UpdateView

    private class RadioButtonHandler implements RadioGroup.OnCheckedChangeListener
    {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId)
        {
            databaseManager.deleteById( checkedId );
            Toast.makeText(DeleteActivity.this, "Candy deleted", Toast.LENGTH_SHORT).show();

            updataView();

        }
    }//end RadioButton


}//end deleteActivity
